import java.awt.*;
import javax.swing.*;

public class BackGround{
  int x,y;
  Image img;// Image class of Graphics2D
  
  BackGround(){
    this.img = 	
      new ImageIcon("background1.gif").getImage();
      // uses ImageIcon class of Graphics2D
  }
  
  void drawBk(){
    Game.canvas.drawImage(this.img,//image file
                          0, //x of (0.0)
                          0, //y of (0,0)
                          Game.width, //img width
                          Game.height,//img height
                          null);   
  }
      int randInt(int lower, int upper){
      int range = upper - lower + 1;
      return (int)(Math.random()*range) + lower;
    }
}