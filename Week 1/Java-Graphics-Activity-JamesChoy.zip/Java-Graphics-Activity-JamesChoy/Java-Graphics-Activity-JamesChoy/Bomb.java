import java.awt.*;
import javax.swing.*;

class Bomb{
  int x,y;
  int dx,dy;
  int size = 40;// diameter? not a circle
  Image img;
  boolean clicked = false;
  
  
  Bomb(int x, int y, int dx, int dy){
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.img = new ImageIcon("bomb1.png").getImage(); 
    // uses ImageIcon class of Graphics2D
  }
  
  void move(){
    //Move bomb down
	if(!clicked){
    this.y += this.dy;
	this.x += this.dx;
    if(this.y > Game.height){
      this.y = 0;
    }
	if(this.x >Game.width){
		this.x = 0;
	}
	if(this.x <0){
		this.x = Game.width;
	}
	if(this.y <0){
		this.y = Game.height;
	}
	if(this.dx < 1 && this.dx>-1){
		this.dx = 1;
	}
	if(this.dy < 1 && this.dy>-1){
		this.dy = 1;
	}

    draw();
  }
  }
  
  void draw(){
    Game.canvas.drawImage(this.img,
                          this.x,
                          this.y,
                          size, //img width
                          size,//img height
                          null);   
  }
  
boolean collidedWithMouse(){
    return Mouse.x >= x &&
           Mouse.x <= x + 40 &&
           Mouse.y >= y &&
           Mouse.y <= y + 40;
}
  
}