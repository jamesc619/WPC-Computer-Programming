import java.awt.*;
import javax.swing.*;
/*
TASK: Create a game that has:
- 50 objects, and you have to click on all of the objects to win.

  */

public class GameLogic {
int count = 0;
BackGround bk = new BackGround();
Bomb bombs[] = new Bomb[50];
  
    public GameLogic() {
		
		for(int i=0; i<bombs.length; i++){
			bombs[i] = new Bomb(randInt(0,Game.width), randInt(0,Game.height),randInt(-5,5),randInt(-5,5));
		}

	  }

    
  
    public void gameLoop(){
      
	  // move each ball in the array
	  for(int i=0; i<bombs.length; i++){
		bombs[i].move();
	  
	  
	  // increment count of collisions of any ball with mouse
		if(bombs[i].collidedWithMouse() && Mouse.leftPressed && !bombs[i].clicked){
			bombs[i].clicked = true;
			Mouse.leftPressed = false;
			count++;
}
	  }
	  if(count == bombs.length){
		Game.canvas.drawString("You Win!", Game.height/2, Game.width/2 );
	  }
	  // display # of collisions   
	  String text = "Targets Shot: " + count;
      Game.canvas.drawString(text, 20, 20);
      
      

    }


  
    // random #
    int randInt(int lower, int upper){
      int range = upper - lower + 1;
      return (int)(Math.random()*range) + lower;
    }

}
